import logging

PLUGIN_ID = "kmarius_video_handler"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")