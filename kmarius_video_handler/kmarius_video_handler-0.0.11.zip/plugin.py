import subprocess
import re
from typing import Optional

from unmanic.libs.unplugins.settings import PluginSettings

from kmarius_executor.lib import init_task_data
from kmarius_video_handler.lib import logger
from kmarius_video_handler.lib.types import *


class Settings(PluginSettings):
    settings = {
        'target_bitrate': 3000,
        'bitrate_cutoff': 4500,
    }
    form_settings = {
        'target_bitrate': {
            'label': 'Target bitrate (kbit/s)',
            'description': 'Target bitrate passed to the h264 encoder',
        },
        'bitrate_cutoff': {
            'label': 'Bitrate cutoff (kbit/s)',
            'description': "Won't re-encode if current bitrate is smaller than this value.",
        },
    }


def _get_bitrate(stream_info: dict, path: str) -> Optional[int]:
    if 'bit_rate' in stream_info:
        return int(stream_info['bit_rate'])
    if 'tags' in stream_info:
        for key, val in stream_info['tags'].items():
            if key.startswith('BPS'):
                return int(val)
    stream_index = stream_info['index']
    proc = subprocess.Popen(['mkvinfo', '-t', path], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    # Example:
    # Statistics for track number 1: number of blocks: 138031; size in bytes: 2127736369; duration in seconds: 5757.041708333; approximate bitrate in bits/second: 2956707
    pattern = bytes(f'Statistics for track number {stream_index + 1}:', 'utf-8')
    for line in proc.stdout:
        if line.startswith(pattern):
            proc.terminate()
            line = line.decode('utf-8').strip()
            return int(line.split()[-1])
    return None


# change everything that is not 8bit h264 with a reasonable bit rate
def needs_encoding(stream_info: dict, path: str, bitrate_cutoff: int) -> bool:
    if stream_info['codec_name'] != 'h264':
        return True

    bit_rate = _get_bitrate(stream_info, path)
    if bit_rate is None:
        logger.error(f'Could not determine bitrate for {path}')

    if bit_rate is not None and bit_rate > bitrate_cutoff:
        return True

    if 'pix_fmt' in stream_info and stream_info['pix_fmt'] != 'yuv420p':
        return True

    return False


def video_stream_mapping(
        stream_info: dict, idx: int, path: str,
        target_bitrate: int, bitrate_cutoff: int) -> Optional[dict]:
    # remove images
    codec_name = stream_info['codec_name']
    if codec_name in ['png', 'mjpeg']:
        return {
            'stream_mapping': [],
            'stream_encoding': [],
        }

    if needs_encoding(stream_info, path, bitrate_cutoff):
        stream_encoding = [
            f'-c:v:{idx}', 'libx264',
            '-pix_fmt', 'yuv420p',
            f'-b:v:{idx}', f'{target_bitrate}'
        ]
        return {
            'stream_mapping': ['-map', f'0:v:{idx}'],
            'stream_encoding': stream_encoding,
        }

    return None


def on_library_management_file_test(data: FileTestData, **kwargs):
    task_data = init_task_data(data)

    settings = Settings(library_id=data.get('library_id'))
    target_bitrate = settings.get_setting('target_bitrate') * 1000
    bitrate_cutoff = settings.get_setting('bitrate_cutoff') * 1000

    video_streams = task_data['streams']['video']
    video_mappings = {}

    path = data['path']
    for idx, stream_info in enumerate(video_streams):
        mapping = video_stream_mapping(stream_info, idx, path, target_bitrate, bitrate_cutoff)
        if mapping is not None:
            video_mappings[idx] = mapping

    task_data['mappings']['video'] = video_mappings
    if video_mappings:
        task_data['add_file_to_pending_tasks'] = True