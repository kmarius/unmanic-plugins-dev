import logging

PLUGIN_ID = "kmarius_debug"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")