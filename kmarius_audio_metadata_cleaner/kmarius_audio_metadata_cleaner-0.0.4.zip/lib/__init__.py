import logging

PLUGIN_ID = "kmarius_audio_metadata_cleaner"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")