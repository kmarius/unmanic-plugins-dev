import logging

PLUGIN_ID = "kmarius_stream_remover"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")