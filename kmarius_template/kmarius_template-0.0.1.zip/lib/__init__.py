import logging

PLUGIN_ID = "kmarius_template"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")