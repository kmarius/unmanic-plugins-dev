import logging

PLUGIN_ID = "kmarius_metadata_handler"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")