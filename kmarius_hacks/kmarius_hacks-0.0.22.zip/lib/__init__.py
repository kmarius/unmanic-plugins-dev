import logging

PLUGIN_ID = "kmarius_hacks"
from .types import *

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")