import logging

PLUGIN_ID = "kmarius_flac_downsampler"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")