import json
import os
import queue
import re
import threading
import time
import traceback
import uuid
from typing import Optional, Collection, Dict, TypeVar, Type

from unmanic.libs.filetest import FileTesterThread
from unmanic.libs.frontend_push_messages import FrontendPushMessages
from unmanic.libs.libraryscanner import LibraryScannerManager
from unmanic.libs.unmodels import Libraries

from . import timestamps, logger, get_files_tested, cache
from .metadata_provider import PROVIDERS
from .types import *


def critical(f):
    '''Decorator to allow only one thread to execute this function at a time.'''
    lock = threading.Lock()

    def wrapped(*args, **kwargs):
        if not lock.acquire(blocking=False):
            logger.error('Could not acquire lock')
            return
        try:
            f(*args, **kwargs)
        finally:
            lock.release()

    return wrapped


T = TypeVar('T')


def _get_thread(clazz: Type[T]) -> Optional[T]:
    for thread in threading.enumerate():
        if type(thread) is clazz:
            return thread
    return None


def _get_library_paths() -> Dict[int, str]:
    paths = {}
    for lib in Libraries().select().where(Libraries.enable_remote_only == False):
        paths[lib.id] = lib.path
    return paths


def _validate_path(path: str, library_path: str) -> bool:
    return path.startswith('/') and '/..' not in path and path.startswith(library_path)


# possibly make this configurable
def _get_icon(name: str) -> str:
    ext = os.path.splitext(name)[1][1:].lower()
    if ext in ['mp4', 'mkv', 'webm', 'avi', 'mov', 'flv']:
        return 'bi bi-film'
    elif ext in ['mp3', 'm4a', 'flac', 'opus', 'ogg']:
        return 'bi bi-music-note-beamed'
    elif ext in ['jpg', 'png', 'bmp']:
        return 'bi bi-image'
    else:
        return 'bi bi-file-earmark'


def _test_files_in_lib(library_id: int, items: Collection[str]):
    num_files = len(items)
    if num_files == 0:
        return

    scanner = _get_thread(LibraryScannerManager)
    num_threads = scanner.settings.get_concurrent_file_testers()

    # pre-fill queue
    files_to_test = queue.Queue()
    files_to_process = queue.Queue()
    for item in items:
        files_to_test.put(item)

    event = scanner.event
    status_updates = queue.Queue()
    frontend_messages = FrontendPushMessages()

    def send_frontend_message(message):
        frontend_messages.update(
            {
                'id': 'libraryScanProgress',
                'type': 'status',
                'code': 'libraryScanProgress',
                'message': message,
                'timeout': 0
            }
        )

    threads = []

    for i in range(num_threads):
        tester = FileTesterThread(f'kmarius-file-tester-{library_id}-{i}',
                                  files_to_test, files_to_process, status_updates,
                                  library_id, event)
        tester.daemon = True
        tester.start()
        threads.append(tester)

    def queue_up_result(item: dict):
        scanner.add_path_to_queue(item.get('path'), library_id, item.get('priority_score'))

    current_file = ''
    while not files_to_test.empty():
        while not files_to_process.empty():
            queue_up_result(files_to_process.get())

        if not status_updates.empty():
            current_file = status_updates.get()
            while not status_updates.empty():
                current_file = status_updates.get()
            percent_completed = (num_files - files_to_test.qsize()) / num_files * 100
            percent_completed_string = '{:.0f}% - Testing: {}'.format(percent_completed, current_file)
            send_frontend_message(percent_completed_string)

        event.wait(0.1)

    while not status_updates.empty():
        current_file = status_updates.get()
    percent_completed_string = '{:.0f}% - Testing: {}'.format(100, current_file)
    send_frontend_message(percent_completed_string)

    for thread in threads:
        thread.stop()

    for thread in threads:
        thread.join()

    while not files_to_process.empty():
        queue_up_result(files_to_process.get())

    frontend_messages.remove_item('libraryScanProgress')

    # ensure all file_queued events have been emitted
    if hasattr(scanner, 'scheduledtasks'):
        while not scanner.scheduledtasks.empty():
            event.wait(0.25)

    values = []
    for path, mtime in get_files_tested(library_id, clear=True).items():
        logger.info(f'Updating timestamp library_id={library_id} path={path} to {mtime} (no processing requested)')
        values.append((library_id, path, mtime))
    timestamps.put_many(values)


@critical
def _test_files_thread(items_per_lib: Dict[int, Collection[str]]):
    for library_id, paths in items_per_lib.items():
        _test_files_in_lib(library_id, paths)


def _unpack_items(body: dict) -> list[dict]:
    if 'arr' in body:
        return body['arr']
    else:
        return [body]


class Panel:
    # we pass the settings class because a library might get added and we need to instantiate the configuration for it
    def __init__(self, settings_cl):
        self.settings = settings_cl()
        self.settings_cl = settings_cl
        # we can cache some things meaningfully. allowed extensions for example, because when they change plugin.py is
        # re-executed and the Panel is re-created
        self._allowed_extensions = {}
        self._ignore_patterns = {}

    # recreate the configuration if a new library is added
    # it should be fine to do this in _get_libraries and _prune_database, because
    # there is no other way to access a new library through the panel
    def _assert_configuration_valid(self):
        if not self.settings.is_valid():
            logger.info('Configuration invalid. Recreating...')
            self.settings = self.settings_cl()

    def _get_allowed_extensions(self, library_id: int) -> list[str] | None:
        if library_id not in self._allowed_extensions:
            extensions = self.settings.get_setting(f'library_{library_id}_extensions').split(',')
            extensions = [ext.strip().lstrip('.') for ext in extensions]
            extensions = [ext for ext in extensions if ext != '']
            self._allowed_extensions[library_id] = extensions
        return self._allowed_extensions[library_id]

    def _is_extension_allowed(self, library_id: int, path: str) -> bool:
        extensions = self._get_allowed_extensions(library_id)
        if not extensions:
            return True
        ext = os.path.splitext(path)[1][1:].lower()
        return ext in extensions

    def _get_ignore_patterns(self, library_id: int) -> list[re.Pattern] | None:
        if library_id not in self._ignore_patterns:
            patterns = []
            for pattern in self.settings.get_setting(f'library_{library_id}_ignored_paths').splitlines():
                pattern = pattern.strip()
                if pattern and not pattern.startswith('#'):
                    patterns.append(re.compile(pattern))
            self._ignore_patterns[library_id] = patterns
        return self._ignore_patterns[library_id]

    def _is_path_ignored(self, library_id: int, path: str) -> bool:
        for pattern in self._get_ignore_patterns(library_id):
            if pattern.search(path):
                return True
        return False

    def _is_in_library(self, library_id: int, path: str) -> bool:
        return self._is_extension_allowed(library_id, path) and not self._is_path_ignored(library_id, path)

    def _walk_library(self, library_id: int, path: str, followlinks=False) -> list[str]:
        extensions = self._get_allowed_extensions(library_id)
        patterns = self._get_ignore_patterns(library_id)
        res = []
        for dirpath, _, filenames in os.walk(path, followlinks=followlinks):
            for filename in filenames:
                if extensions:
                    ext = os.path.splitext(filename)[1][1:].lower()
                    if ext not in extensions:
                        continue
                path = os.path.join(dirpath, filename)
                for pattern in patterns:
                    if pattern.match(path):
                        continue
                res.append(path)
        return res

    def _test_files(self, items: list[dict]):
        library_paths = _get_library_paths()

        distinct_per_lib = {}

        for item in items:
            library_id = item['library_id']
            path = item['path']

            if not _validate_path(path, library_paths[library_id]):
                raise Exception(f'Invalid path: library_id={library_id}, path={path}')

            if not library_id in distinct_per_lib:
                distinct_per_lib[library_id] = set()

            if os.path.isdir(path):
                distinct_per_lib[library_id].update(self._walk_library(library_id, path))
            else:
                distinct_per_lib[library_id].add(path)

        threading.Thread(
            target=_test_files_thread,
            args=(distinct_per_lib,),
            daemon=True
        ).start()

    def _process_files(self, items: list[dict]):
        library_paths = _get_library_paths()

        scanner = _get_thread(LibraryScannerManager)
        if scanner is None:
            raise Exception(f'Could not get LibraryScanner thread')

        distinct = set()

        for item in items:
            library_id = item['library_id']
            path = item['path']
            priority_score = item['priority_score']

            if not _validate_path(path, library_paths[library_id]):
                raise Exception(f'Invalid path: library_id={library_id}, path={path}')

            if os.path.isdir(path):
                for path in self._walk_library(library_id, path):
                    distinct.add((library_id, path, priority_score))
            else:
                distinct.add((library_id, path, priority_score))

        for library_id, path, priority_score in distinct:
            scanner.add_path_to_queue(path, library_id, priority_score)

    # this function can't load single files currently, only directories with their files
    def _load_subtree(self, path: str, title: str, library_id: int, lazy=True, hide_empty=False,
                      prune_ignored=False, timestamp_cache=None) -> dict:
        children = []
        files = []

        if not (prune_ignored and self._is_path_ignored(library_id, path)):
            with os.scandir(path) as entries:
                for entry in entries:
                    name = entry.name
                    # we unconditionally skip all dotfiles and -dirs
                    if name.startswith('.'):
                        continue

                    abspath = os.path.abspath(os.path.join(path, name))

                    if not (prune_ignored and self._is_path_ignored(library_id, abspath)):
                        if entry.is_dir():
                            if lazy:
                                children.append({
                                    'title': name,
                                    'library_id': library_id,
                                    'path': abspath,
                                    'lazy': True,
                                    'type': 'folder',
                                })
                            else:
                                child = self._load_subtree(abspath, name, library_id,
                                                           lazy=False, hide_empty=hide_empty,
                                                           prune_ignored=prune_ignored, timestamp_cache=timestamp_cache)
                                if not (hide_empty and len(child['children']) == 0):
                                    children.append(child)
                        else:
                            if self._is_in_library(library_id, abspath):
                                file_info = os.stat(abspath)
                                files.append({
                                    'title': name,
                                    'library_id': library_id,
                                    'path': abspath,
                                    'mtime': int(file_info.st_mtime),
                                    'size': int(file_info.st_size),
                                    'icon': _get_icon(name),
                                })

            children.sort(key=lambda c: c['title'])
            files.sort(key=lambda c: c['title'])

            if files:
                if timestamp_cache:
                    for file in files:
                        file['timestamp'] = timestamp_cache.get(file['path'], None)
                else:
                    paths = [file['path'] for file in files]
                    for i, timestamp in enumerate(timestamps.get_many(library_id, paths)):
                        files[i]['timestamp'] = timestamp

            children += files

        return {
            'title': title,
            'children': children,
            'library_id': library_id,
            'path': path,
            'type': 'folder',
        }

    def _get_subtree(self, arguments) -> dict:
        library_id = arguments['library_id'][0]

        # winderbaum calls this with undefined parameters if all nodes are filtered away
        if library_id == 'undefined':
            return {
                'title': 'undefined',
                'children': [],
            }
        library_id = int(library_id)
        path = arguments['path'][0]
        title = arguments['path'][0]

        library = Libraries().select().where(Libraries.id == library_id).first()

        if library.enable_remote_only:
            raise Exception('Library is remote only')

        if not path.startswith(library.path) or '/..' in path:
            raise Exception('Invalid path')

        lazy = self.settings.get_setting(f'library_{library.id}_lazy_load')
        hide_empty = self.settings.get_setting(f'library_{library_id}_hide_empty')
        prune_ignored = self.settings.get_setting(f'library_{library_id}_prune_ignored')

        # if we are loading an entire library it is much faster to create a hashmap of all files and timestamps
        timestamp_cache = None
        if not lazy and path == library.path:
            timestamp_cache = timestamps.get_all(library_id)

        return self._load_subtree(path, title, library_id, lazy=lazy, hide_empty=hide_empty,
                                  prune_ignored=prune_ignored, timestamp_cache=timestamp_cache)

    def _reset_timestamps(self, items: list[dict]):
        library_paths = _get_library_paths()
        distinct = set()
        for item in items:
            library_id = item['library_id']
            path = item['path']

            if not _validate_path(path, library_paths[library_id]):
                raise Exception(f'Invalid path: library_id={library_id}, path={path}')

            if os.path.isdir(path):
                for p in self._walk_library(library_id, path):
                    distinct.add((library_id, p, 0))
            else:
                distinct.add((library_id, path, 0))

        timestamps.put_many(distinct)
        logger.info(f'Reset {len(distinct)} timestamps')

    def _reset_metadata_timestamps(self, items: list[dict]):
        library_paths = _get_library_paths()
        distinct = set()
        for item in items:
            library_id = item['library_id']
            path = item['path']

            if not _validate_path(path, library_paths[library_id]):
                raise Exception(f'Invalid path: library_id={library_id}, path={path}')

            if os.path.isdir(path):
                for p in self._walk_library(library_id, path):
                    distinct.add(p)
            else:
                distinct.add(path)

        count = 0
        for provider in PROVIDERS:
            count += cache.reset_many(provider.name, distinct)
        logger.info(f'Reset {count} metadata items')

    def _update_timestamps(self, items: list[dict]):
        library_paths = _get_library_paths()
        distinct = set()
        for item in items:
            library_id = item['library_id']
            path = item['path']

            if not _validate_path(path, library_paths[library_id]):
                raise Exception(f'Invalid path: library_id={library_id}, path={path}')

            if os.path.isdir(path):
                for p in self._walk_library(library_id, path):
                    distinct.add((library_id, p))
            else:
                distinct.add((library_id, path))

        values = []
        for library_id, path in distinct:
            try:
                mtime = int(os.path.getmtime(path))
                values.append((library_id, path, mtime))
            except OSError as e:
                logger.error(f'{e}: library_id={library_id} path={path}')

        timestamps.put_many(values)
        logger.info(f'Updated {len(values)} timestamps')

    @critical
    def _prune_database(self, payload: dict):
        self._assert_configuration_valid()

        library_ids = []
        library_paths = _get_library_paths()

        if 'library_id' in payload:
            library_ids.append(payload['library_id'])
        else:
            for lib in Libraries().select().where(Libraries.enable_remote_only == False):
                library_ids.append(lib.id)

        num_pruned = 0
        for library_id in library_ids:
            logger.info(f'Pruning library {library_id}')

            paths = []
            for path in timestamps.get_all_paths(library_id):
                if not _validate_path(path, library_paths[library_id]):
                    paths.append(path)
                elif not self._is_in_library(library_id, path) or not os.path.exists(path):
                    paths.append(path)

            timestamps.remove_paths(library_id, paths)

            num_pruned += len(paths)
        logger.info(f'Pruned {num_pruned} orphans')

    def _get_libraries(self, lazy=True) -> dict:
        self._assert_configuration_valid()
        libraries = []
        for lib in Libraries().select().where(Libraries.enable_remote_only == False):
            libraries.append({
                'title': lib.name,
                'library_id': lib.id,
                'path': lib.path,
                'type': 'folder',
                'lazy': lazy,
            })

        return {
            'children': libraries,
        }

    @staticmethod
    def render_frontend_panel(data: PanelData):
        data['content_type'] = 'text/html'

        with (open(os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'index.html'))) as file):
            content = file.read()
            content = content.replace('ENABLE_EXTENDED_ACTIONS = false', 'ENABLE_EXTENDED_ACTIONS = true')
            content = content.replace('{cache_buster}', str(uuid.uuid4()))
            data['content'] = content

    def render_plugin_api(self, data: PluginApiData):
        data['content_type'] = 'application/json'

        arguments = data['arguments']
        for arg, ls in arguments.items():
            arguments[arg] = [val.decode('utf-8') for val in ls]

        if not data['body']:
            body = {}
        else:
            body = json.loads(data['body'].decode('utf-8'))

        try:
            match data['path'], data['method']:
                case '/test', 'POST':
                    self._test_files(_unpack_items(body))
                case '/process', 'POST':
                    self._process_files(_unpack_items(body))
                case '/subtree', 'GET':
                    data['content'] = self._get_subtree(arguments)
                case '/libraries', 'GET':
                    data['content'] = self._get_libraries()
                case '/timestamp/reset', 'POST':
                    self._reset_timestamps(_unpack_items(body))
                case '/timestamp/update', 'POST':
                    self._update_timestamps(_unpack_items(body))
                case '/metadata/reset', 'POST':
                    self._reset_metadata_timestamps(_unpack_items(body))
                case '/prune', 'POST':
                    threading.Thread(target=self._prune_database,
                                     args=(body,),
                                     daemon=True).start()
                case path, method:
                    data['content'] = {
                        'success': False,
                        'error': f'unknown path: {method} {path}',
                    }
                    data['status'] = 404

        except Exception as e:
            trace = traceback.format_exc()
            logger.error(trace)
            data['content'] = {
                'success': False,
                'error': str(e),
                'trace': trace,
            }
            data['status'] = 503