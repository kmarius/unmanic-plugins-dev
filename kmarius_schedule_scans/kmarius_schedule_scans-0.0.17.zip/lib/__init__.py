import logging

PLUGIN_ID = "kmarius_schedule_scans"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")