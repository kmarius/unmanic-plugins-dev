import logging

PLUGIN_ID = "kmarius_notify"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")