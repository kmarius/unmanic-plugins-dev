import logging

PLUGIN_ID = "kmarius_container_handler"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")