import logging

PLUGIN_ID = "kmarius_interleave_mp4"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")