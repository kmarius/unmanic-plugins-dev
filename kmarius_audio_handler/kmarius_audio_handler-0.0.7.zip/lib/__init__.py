import logging

PLUGIN_ID = "kmarius_audio_handler"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")